package sidescroller.scene;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;

import javafx.scene.canvas.Canvas;
import javafx.util.Pair;
import sidescroller.entity.GenericEntity;
import sidescroller.entity.property.Entity;
import sidescroller.entity.property.HitBox;
import sidescroller.entity.property.Sprite;
import sidescroller.entity.sprite.BackgroundSprite;
import sidescroller.entity.sprite.LandSprite;
import sidescroller.entity.sprite.PlatformSprite;
import sidescroller.entity.sprite.SpriteFactory;
import sidescroller.entity.sprite.TreeSprite;
import sidescroller.entity.sprite.tile.BackgroundTile;
import sidescroller.entity.sprite.tile.Tile;
import utility.Tuple;

public class MapBuilder implements MapBuilderInterface{
	private Tuple rowColCount;
	private Tuple dimension;
	private double scale;
	private Canvas canvas;
	private Entity background;
	private List<Entity> landMass;
	private List<Entity> other;
	
	protected MapBuilder() {
		landMass = new ArrayList<>();
		other = new ArrayList<>();
	}
	
	public static MapBuilder createBuilder() {
		return new MapBuilder();
	}
	
	public MapBuilder setCanvas(Canvas canvas) {
		this.canvas = canvas;
		return this;
		
	}
	
	public MapBuilder setGrid(Tuple rowColCount, Tuple dimension) {

		this.rowColCount = rowColCount;
		this.dimension = dimension;
		return this;
		
	}
	
	public MapBuilder buildBackground(BiFunction<Integer, Integer, Tile>callback) {

		BackgroundSprite backgroundSpirit = SpriteFactory.get("Background");
		backgroundSpirit.init(scale, dimension, Tuple.pair(0, 0));
		backgroundSpirit.createSnapshot(canvas, rowColCount, callback);
		HitBox hitBox = HitBox.build(0, 0, scale*dimension.x()*rowColCount.y(), scale*dimension.y()*rowColCount.x());
		background = new GenericEntity(backgroundSpirit,hitBox);

			return this;

	}
	
	public MapBuilder buildLandMass(int rowPost, int colPos, int rowConut, int colCount) {
		LandSprite landSprite = SpriteFactory.get("Land");
		landSprite.init(scale, dimension, Tuple.pair(colPos, rowPost));
		landSprite.createSnapshot(canvas, rowConut, colCount);
//		HitBox hitBox = HitBox.build(colPos*dimension.x()*scale, rowPost*dimension.y()*scale, scale*dimension.x(), scale*dimension.y()*rowConut);
		HitBox hitBox = HitBox.build(colPos*dimension.x()*scale, rowPost*dimension.y()*scale, scale*dimension.x()* colCount, scale*dimension.y()*rowConut);
		landMass.add(new GenericEntity(landSprite, hitBox));
		return this;
	}
	
	public MapBuilder buildTree(int rowPos, int colPos, Tile tile) {
		TreeSprite tree = SpriteFactory.get("Tree");
		tree.init(scale, dimension, Tuple.pair(colPos, rowPos));
		tree.createSnapshot(canvas, tile);
		other.add(new GenericEntity(tree, null));
		return this;
	}
	
	public MapBuilder buildPlatform(int rowPos, int colPos, int length, Tile tile) {
		PlatformSprite plateformSprite = SpriteFactory.get("Platform");
		plateformSprite.init(scale, dimension, Tuple.pair(colPos, rowPos));
		plateformSprite.createSnapshot(canvas, tile, length);
		HitBox hitBox = HitBox.build((colPos + 0.5)*dimension.x()*scale, rowPos*dimension.y()*scale, scale*dimension.x()*(length - 1), dimension.y() / 2);
		other.add(new GenericEntity(plateformSprite, hitBox));
		return this;
	}
	
	public List<Entity> getEntities(List<Entity> list){
		list.addAll(landMass);
		list.addAll(other);
		return list;
	}
	
	public MapBuilder setGridScale(double scale) {
		this.scale = scale;
		return this;
	}

	@Override
	public Entity getBackground() {
		return background;
	}
	
	

	
}
