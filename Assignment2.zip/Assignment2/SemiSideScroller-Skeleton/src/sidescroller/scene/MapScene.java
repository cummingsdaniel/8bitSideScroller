package sidescroller.scene;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.canvas.Canvas;
import sidescroller.animator.AnimatorInterface;
import sidescroller.entity.property.Entity;
import sidescroller.entity.property.HitBox;
import sidescroller.entity.sprite.tile.BackgroundTile;
import sidescroller.entity.sprite.tile.FloraTile;
import sidescroller.entity.sprite.tile.Tile;
import utility.Tuple;

public class MapScene implements MapSceneInterface {
	private Tuple count;
	private Tuple size;
	private double scale;
	private AnimatorInterface animatorInterface;
	private List<Entity> players;
	private List<Entity> staticShapes;
	private BooleanProperty drawBounds;
	private BooleanProperty drawFPS;
	private BooleanProperty drawGrid;
	private Entity background;

	public MapScene() {
		// TODO look at the class diagram for the rest of the details.
		// Initialize the lists and BooleanProperties inside of the constructor.
		// to initialize a BooleanProperties use the class SimpleBooleanProperty.
		// you need to pay attention to these, you made the same mistake again.
		// constructor is for initializations, you are calling the player method which
		// is
		// a ggetter to init this variable, you cannot do this.
		players = new ArrayList<>();// same for below
		staticShapes = new ArrayList<>();;
		drawBounds = new SimpleBooleanProperty();
		drawFPS = new SimpleBooleanProperty();
		drawGrid = new SimpleBooleanProperty();
	}

	public BooleanProperty drawFPSProperty() {
		/**
		 * @return the drawFPS instance.
		 */
		return drawFPS;
	}

	public boolean getDrawFPS() {
		/**
		 * @return the value of {@link BooleanProperty#get()}
		 */
		return drawFPS.get();
	}

	public BooleanProperty drawBoundsProperty() {
		/**
		 * @return the drawBounds instance.
		 */
		return drawBounds;
	}

	public boolean getDrawBounds() {
		/**
		 * @return the value of {@link BooleanProperty#get()}
		 */
		return drawBounds.get();
	}

	public BooleanProperty drawGridProperty() {
		/**
		 * @return the drawGrid instance.
		 */
		return drawGrid;
	}

	public boolean getDrawGrid() {
		/**
		 * @return the value of {@link BooleanProperty#get()}
		 */
		return drawGrid.get();
	}

	public MapScene setRowAndCol(Tuple count, Tuple size, double scale) {
		/**
		 * save date in the correct variables.
		 * 
		 * @param count - number of rows and columns in the grid.
		 * @param size  - width and height of each cell in grid.
		 * @param scale - a double multiplier for width and height of each grid cell.
		 * @return current instance of this class.
		 */
		this.count = count;
		this.size = size;
		this.scale = scale;
		return this;
	}

	public Tuple getGridCount() {
		/**
		 * @return count variable.
		 */
		return count;
	}

	public Tuple getGridSize() {
		/**
		 * @return size variable.
		 */
		return size;
	}

	public void start() {
		/**
		 * @return scale variable.
		 */
		if (this.animatorInterface != null) {
			this.animatorInterface.start();
		}
	}

	public void stop() {
		if (this.animatorInterface != null) {
			this.animatorInterface.stop();
		}
	}

	public List<Entity> staticShapes() {
		return staticShapes;
	}

	public List<Entity> players() {
		return players;
	}

	public MapScene createScene(Canvas canvas) {
		MapBuilder mb = MapBuilder.createBuilder();
		mb.setCanvas(canvas);
		mb.setGrid(count, size);
		mb.setGridScale(this.scale);
		
		BiFunction<Integer, Integer, Tile> buildMap = (row, col)-> {
//			if(row < 8 && Math.random() > 0.88)
//				return BackgroundTile.MORNING_CLOUD;
			return BackgroundTile.MORNING;
			
		};
		
		mb.buildBackground(buildMap);
		mb.buildLandMass(9, 5, 4, 23);
		mb.buildTree(2, 7, FloraTile.TREE);
		mb.buildTree(4, 23, FloraTile.TREE_DEAD);
		mb.buildTree(0, 4, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(0, 9, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(0, 14, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(0, 19, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(0, 24, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(0, 34, BackgroundTile.MORNING_CLOUD);
		
		mb.buildTree(1, 2, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(1, 4, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(1, 8, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(1, 8, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(1, 10, BackgroundTile.MORNING_CLOUD);
		mb.buildTree(1, 34, BackgroundTile.MORNING_CLOUD);

		background = mb.getBackground();
//		mb.buildTree(8, 10, FloraTile.SUNFLOWER_LONG);
		mb.getEntities(staticShapes);
		return this;
	}

	public boolean inMap(HitBox hitbox) {
		/**
		 * @param hitbox - hitbox of an entity to check it is it still in background
		 *               bounds.
		 * @return true of hitbox of background containsBouns of argument.
		 */
		// you are checking if an external hitbox is inside of your background (map)
		return background.getHitBox().containsBounds(hitbox);
	}

	public MapScene setAnimator(AnimatorInterface newAnimator) {
		/**
		 * if current animator instance is not null stop it first. then assign the
		 * newAnimator to animator.
		 * 
		 * @param newAnimator - new animator to set.
		 * @return current instance of this class.
		 * @throws NullPointerException if argument is null.
		 */
		if (this.animatorInterface != null) {
			this.animatorInterface.stop();
		}
		this.animatorInterface = newAnimator;
		return this;
	}

	@Override
	public double getScale() {
		// TODO Auto-generated method stub
		
		return scale;
	}

	@Override
	public Entity getBackground() {
		// TODO Auto-generated method stub
		return background;
	}
}
