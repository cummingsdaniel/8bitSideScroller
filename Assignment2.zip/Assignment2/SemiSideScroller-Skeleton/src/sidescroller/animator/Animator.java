package sidescroller.animator;

import java.util.Iterator;
import java.util.function.Consumer;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.ArcType;
import sidescroller.entity.player.Player;
import sidescroller.entity.property.Drawable;
import sidescroller.entity.property.Entity;
import sidescroller.entity.property.HitBox;

public class Animator extends AbstractAnimator {
	private Color background = Color.ANTIQUEWHITE;

	public void handle(GraphicsContext gc, long now) {
		updateEntities();
		clearAndFill(gc, background);
		drawEntities(gc);
	}

	public void drawEntities(GraphicsContext gc) {
		//same as just saying e
		Consumer<Entity> draw;
		
//		draw = new Consumer<Entity>() {
//			
//			@Override
//			public void accept(Entity e) {
//				if(e!=null && e.isDrawable()) {
//					Drawable<?> drawable = e.getDrawable();
//					drawable.draw(gc);
//					if(map.getDrawBounds() && e.hasHitbox()) {
//						HitBox hitbox = e.getHitBox();
//						hitbox.getDrawable().draw(gc);
//					}
//				}
//			}
//		};
		
			draw= (Entity e)->{
			if(e!=null && e.isDrawable()) {
				e.getDrawable().draw(gc);
//				Drawable<?> drawable = e.getDrawable();
//				drawable.draw(gc);
				if(map.getDrawBounds() && e.hasHitbox()) {
//					HitBox hitbox = e.getHitBox();
//					hitbox.getDrawable().draw(gc);
					
					e.getHitBox().getDrawable().draw(gc);
				}
			}
		};
		
		
		//why is this up here?
		//the location is irrelevant. it was y in the diagram it was refactored.
		//but here when writing the code the dfinition of draw must go with its init.
		//otherwise everthing will get a nullpointer exceptions.
		//in the diagram instead of showing the accept method 3 times, we refcator it and show it
		//once at the very end. because everytime the method accept is called the definition below
		//is called you simply have to follow it, but when writing the code these restriction do not
		//exist instead we have to follow the rules of java.
		
		//so your saying im still missing code in this method?
		//no you are done. you have the lambda defined, called the draw for background and the two loops
		//but shouldn't I be calling draw.accept outside the loop and before the lambda?
		//no, step 2 is an anonymous message call, meaning we dont know when or how but someone has
		//called this method. it is not part of step 1, it is stand alone.
		//ok
		draw.accept(map.getBackground());
		
		for(Entity e : map.staticShapes()) {
			draw.accept(e);
		}
		
//		for(int i = 0; i < map.players().size(); i++ ) {
//			draw.accept(map.players().get(i));
//		}
		
		map.players().forEach(draw);
		
//		for(Entity e : map.players()) {
//			draw.accept(e);
//		}

	}

	public void updateEntities() {
		for (Entity e : map.players()) {
			e.update();
		}
		
		for(Entity e : map.staticShapes()) {
			e.update();
		}
		
		if(map.getDrawBounds()) {
			for(Entity e : map.players()) {
				e.getHitBox();
				e.getDrawable();
				e.getDrawable().setStroke(Color.RED);
			}
		}
		for(Entity e: map.staticShapes()) {
			proccessEntityList(map.players().iterator(), e.getHitBox());
		}
	}

	public void proccessEntityList(Iterator<Entity> iterator, HitBox shapeHitBox) {
		Entity entity;
		while (iterator.hasNext()) {
			entity = iterator.next();
			HitBox bounds = entity.getHitBox();
			if (!map.inMap(bounds)) {
				updateEntity(entity, iterator);
			} else if (shapeHitBox != null && bounds.intersectBounds(shapeHitBox)) {
				if (map.getDrawBounds()) {
					Paint paint = Color.BLUEVIOLET;
					Drawable<?> drawable = bounds.getDrawable();
					drawable.setStroke(paint);
				}
				updateEntity(entity, iterator);
			}
		}

	}

	public void updateEntity(Entity entity, Iterator<Entity> iterator) {

		if (entity instanceof Player) {
			((Player) entity).stepBack();
		}
	}
}
