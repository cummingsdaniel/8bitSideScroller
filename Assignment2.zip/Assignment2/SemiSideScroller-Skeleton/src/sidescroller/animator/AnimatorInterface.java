package sidescroller.animator;

import java.util.Iterator;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import sidescroller.entity.property.Entity;
import sidescroller.entity.property.HitBox;
import sidescroller.scene.MapSceneInterface;

public interface AnimatorInterface{

	public void setCanvas( Canvas canvas);

	public void setMapScene( MapSceneInterface map);

	public void clearAndFill( GraphicsContext gc, Color background);

	public void handle( GraphicsContext gc, long now);

	public void drawEntities( GraphicsContext gc);

	public void updateEntities();

	public void proccessEntityList( Iterator< Entity> iterator, HitBox shapeHitBox);

	public void updateEntity( Entity entity, Iterator< Entity> iterator);
	
	public void start();
	
	public void stop();
}
