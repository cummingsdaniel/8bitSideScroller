package sidescroller.animator;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import sidescroller.entity.FpsCounter;
import sidescroller.entity.Grid;
import sidescroller.entity.property.Drawable;
import sidescroller.scene.MapSceneInterface;
import utility.Tuple;
//I tryed doing that once becafore but its only now that no errors are poping up from it. :/
//because you did not implement all the methods
//oh
public abstract class AbstractAnimator extends AnimationTimer implements AnimatorInterface{
	protected MapSceneInterface map;
	protected Tuple mouse;
	private Canvas canvas;
	private FpsCounter fps;
	private Grid grid;
	
	public AbstractAnimator() {
		fps = new FpsCounter(10, 25);
		fps.getDrawable().setFill(Color.BLACK).setWidth(1);
		Drawable<?> fspSprite = fps.getDrawable();
		fspSprite.setFill(Color.BLACK);
		fspSprite.setStroke(Color.WHITE);
		fspSprite.setWidth(1.0);
		
	}
	
	private void test() {
		
	}
	
	public void clearAndFill(GraphicsContext gc, Color background) {
		gc.setFill(background);
		gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
		gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
	}
	
	public void handle(long now) {
		GraphicsContext gc = canvas.getGraphicsContext2D();
		if(map.getDrawFPS()) {
			fps.calculateFPS(now);
		}
		handle(gc, now);
		if(map.getDrawGrid()) {
			if(grid==null) {
				grid = new Grid(map.getGridCount(), canvas.getWidth(), canvas.getHeight());
				Drawable<?> gridSprite = grid.getDrawable();
				gridSprite.setStroke(Color.BLACK);
				gridSprite.setWidth(1.0);
				gridSprite.setScale(map.getScale());
				gridSprite.setTileSize(map.getGridSize());
			}
			grid.getDrawable().draw(gc);	
		}
		if(map.getDrawFPS()) {
			fps.getDrawable().draw(gc);
		}
	}
	
	public abstract void handle(GraphicsContext gc, long now);
	
	public void setMapScene(MapSceneInterface map) {
		//you are calling your own method, this is a setter
		//what do we do in side setter???
		//I am calling the method in the animator interface
		//why? interface is just a guidline, it does not do anything
		this.map=map;
//		setMapScene(map);
	}
	
	//also you did not make the method
	//It wasn't in the uml
	//it doe snot have to be, you inherit from an interface
	//either the abstract class or one of the concrete classes must implement all the methods
	//that is the rule of programing, it is implied, there is no need to show it in the diagrams.
	//ok then. 
	public void setCanvas(Canvas canvas) {
		this.canvas = canvas;
	}

}
